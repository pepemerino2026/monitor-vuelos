"""Fuentes de precios.

- FastFlights: lee Google Flights gratis (sin clave). Barrido de fechas y aeropuertos.
- SerpApi: plan gratuito 250 consultas/mes. Calificación de precio de Google,
  historial y precios por vendedor (aerolínea vs OTAs).
- Simulado: datos ficticios para probar sin conexión (--simular).
"""
from __future__ import annotations

import hashlib
import json
import os
import random
import time
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path


@dataclass
class Oferta:
    origen: str
    destino: str
    ida: str
    vuelta: str | None
    precio: float
    aerolineas: str
    escalas: int
    duracion_min: int
    conexiones: list[str] = field(default_factory=list)
    url: str = ""


def _url_google(origen, destino, ida, vuelta, moneda="USD"):
    q = f"Flights from {origen} to {destino} on {ida}"
    if vuelta:
        q += f" returning {vuelta}"
    from urllib.parse import quote_plus
    return f"https://www.google.com/travel/flights?q={quote_plus(q)}&curr={moneda}"


# ---------------------------------------------------------------------------
class FastFlights:
    nombre = "google_flights"

    def __init__(self, cfg_general):
        self.moneda = cfg_general.get("moneda", "USD")
        self.idioma = cfg_general.get("idioma", "es")
        self.pausa = cfg_general.get("pausa_entre_consultas_seg", 3)

    def buscar(self, origen, destino, ida, vuelta, adultos=1, clase="economy",
               escalas_max=None, maletas=0) -> list[Oferta]:
        from fast_flights import FlightQuery, Passengers, create_query, get_flights
        tramos = [FlightQuery(date=ida, from_airport=origen, to_airport=destino)]
        if vuelta:
            tramos.append(FlightQuery(date=vuelta, from_airport=destino, to_airport=origen))
        q = create_query(
            flights=tramos,
            trip="round-trip" if vuelta else "one-way",
            seat=clase,
            passengers=Passengers(adults=adultos),
            currency=self.moneda,
            language=self.idioma,
            max_stops=escalas_max,
            checked_bags=maletas,
        )
        time.sleep(self.pausa)
        try:
            res = get_flights(q)
        except Exception as e:  # sin resultados o bloqueo puntual
            print(f"   ! {origen}-{destino} {ida}: {type(e).__name__}")
            return []
        url = q.url()
        out = []
        for f in res:
            segs = f.flights or []
            # en ida y vuelta Google lista los tramos de ida; el precio es el total del viaje
            conex = [s.to_airport.code for s in segs[:-1]]
            out.append(Oferta(
                origen=origen, destino=destino, ida=ida, vuelta=vuelta,
                precio=float(f.price), aerolineas=", ".join(f.airlines),
                escalas=max(len(segs) - 1, 0),
                duracion_min=sum(s.duration for s in segs),
                conexiones=conex, url=url,
            ))
        return out


# ---------------------------------------------------------------------------
class SerpApi:
    URL = "https://serpapi.com/search.json"

    def __init__(self, cfg, cfg_general, carpeta_datos: Path):
        self.clave = os.environ.get("SERPAPI_KEY", "")
        self.activo = bool(cfg.get("activo")) and bool(self.clave)
        self.presupuesto = cfg.get("presupuesto_mensual", 240)
        self.moneda = cfg_general.get("moneda", "USD")
        self.idioma = cfg_general.get("idioma", "es")
        self.pais = cfg_general.get("pais", "cl")
        self.archivo_uso = carpeta_datos / "uso_serpapi.json"

    # control de presupuesto mensual
    def _uso(self):
        mes = date.today().strftime("%Y-%m")
        try:
            d = json.loads(self.archivo_uso.read_text())
        except Exception:
            d = {}
        return mes, d

    def restantes(self):
        mes, d = self._uso()
        return self.presupuesto - d.get(mes, 0)

    def _gastar(self, n=1):
        mes, d = self._uso()
        d[mes] = d.get(mes, 0) + n
        self.archivo_uso.write_text(json.dumps(d))

    def _get(self, params):
        import requests
        if not self.activo or self.restantes() <= 0:
            return None
        p = {"engine": "google_flights", "api_key": self.clave, "currency": self.moneda,
             "hl": self.idioma, "gl": self.pais, **params}
        r = requests.get(self.URL, params=p, timeout=60)
        self._gastar()
        if r.status_code != 200:
            print(f"   ! SerpApi {r.status_code}: {r.text[:120]}")
            return None
        return r.json()

    def _base(self, b, origenes, destinos, ida, vuelta):
        clase = {"economy": 1, "premium-economy": 2, "business": 3, "first": 4}
        p = {"departure_id": ",".join(origenes), "arrival_id": ",".join(destinos),
             "outbound_date": ida, "type": 1 if vuelta else 2,
             "adults": b.get("adultos", 1), "travel_class": clase.get(b.get("clase", "economy"), 1)}
        if vuelta:
            p["return_date"] = vuelta
        if b.get("maletas_documentadas"):
            p["bags"] = b["maletas_documentadas"]
        em = b.get("escalas_max")
        if em is not None:
            p["stops"] = {0: 1, 1: 2, 2: 3}.get(em, 0)
        return p

    def insights(self, b, origenes, destinos, ida, vuelta):
        """Calificación de precio (low/typical/high), rango típico e historial."""
        d = self._get(self._base(b, origenes, destinos, ida, vuelta))
        if not d:
            return None
        pi = d.get("price_insights") or {}
        vuelos = (d.get("best_flights") or []) + (d.get("other_flights") or [])
        return {
            "nivel": pi.get("price_level"),
            "precio_mas_bajo": pi.get("lowest_price"),
            "rango_tipico": pi.get("typical_price_range"),
            "historial": pi.get("price_history"),
            "url": (d.get("search_metadata") or {}).get("google_flights_url"),
            "_vuelos": vuelos,
            "_params": self._base(b, origenes, destinos, ida, vuelta),
        }

    def vendedores(self, ins, es_ida_vuelta):
        """Precios por vendedor del mejor vuelo (3 consultas en ida y vuelta)."""
        if not ins or not ins.get("_vuelos"):
            return []
        v = ins["_vuelos"][0]
        aerolineas = {s.get("airline", "") for s in v.get("flights", [])}
        token = v.get("booking_token")
        if not token and es_ida_vuelta and v.get("departure_token"):
            d = self._get({**ins["_params"], "departure_token": v["departure_token"]})
            ret = ((d or {}).get("best_flights") or []) + ((d or {}).get("other_flights") or [])
            if ret:
                token = ret[0].get("booking_token")
                aerolineas |= {s.get("airline", "") for s in ret[0].get("flights", [])}
        if not token:
            return []
        d = self._get({**ins["_params"], "booking_token": token})
        out = []
        for op in (d or {}).get("booking_options", []):
            t = op.get("together") or op.get("departing") or {}
            nombre = t.get("book_with", "?")
            precio = t.get("price")
            if precio is None:
                continue
            es_aerolinea = any(a and (a.lower() in nombre.lower() or nombre.lower() in a.lower())
                               for a in aerolineas)
            out.append({"vendedor": nombre, "precio": float(precio),
                        "tipo": "Aerolínea" if es_aerolinea else "Agencia (OTA)",
                        "separado": bool(op.get("separate_tickets"))})
        return out


# ---------------------------------------------------------------------------
class Simulado:
    """Precios ficticios coherentes (para pruebas). Varían por fecha de consulta."""
    nombre = "simulado"

    def __init__(self, hoy: date):
        self.hoy = hoy

    def _rng(self, *k):
        s = int(hashlib.md5("|".join(map(str, k)).encode()).hexdigest()[:8], 16)
        return random.Random(s)

    def buscar(self, origen, destino, ida, vuelta, adultos=1, clase="economy",
               escalas_max=None, maletas=0):
        base = {"MAD": 1150, "BCN": 1220, "LIS": 1180, "FCO": 1300, "CDG": 1260,
                "GRU": 420, "EZE": 260, "LIM": 380}.get(destino, 900)
        if origen in ("GRU", "EZE", "LIM"):
            base = {"MAD": 640, "BCN": 700, "LIS": 610}.get(destino, 700)
        if origen == "MDZ":
            base *= 1.06
        d_ida = datetime.strptime(ida, "%Y-%m-%d").date()
        semana = d_ida.isocalendar()[1]
        estacional = 1 + 0.12 * ((semana % 6) - 2.5) / 2.5          # semanas caras/baratas
        dia = {1: 0.93, 2: 0.94, 3: 0.97, 4: 1.06, 6: 1.04}.get(d_ida.weekday(), 1.0)
        anticip = (d_ida - self.hoy).days
        curva = 1.0 + max(0, 60 - anticip) * 0.006 + max(0, anticip - 180) * 0.0015
        ruido = 1 + self._rng(origen, destino, ida, vuelta, self.hoy).uniform(-0.07, 0.07)
        factor_viaje = 1.0 if vuelta else 0.62
        p0 = base * estacional * dia * curva * ruido * factor_viaje * adultos
        r = self._rng(origen, destino, ida, vuelta)
        out = []
        for i, (aer, conx) in enumerate([("LATAM", ["GRU"]), ("Iberia", []), ("Air Europa", ["EZE"])]):
            conexiones = conx if destino not in ("GRU", "EZE", "LIM") else []
            out.append(Oferta(origen, destino, ida, vuelta, round(p0 * (1 + 0.06 * i + r.uniform(0, .03))),
                              aer, len(conexiones), 780 + 120 * len(conexiones), conexiones,
                              _url_google(origen, destino, ida, vuelta)))
        if destino in ("FCO", "CDG"):   # para probar ciudad oculta: conexión en MAD
            out.append(Oferta(origen, destino, ida, vuelta, round(p0 * 0.78), "Iberia", 1, 960,
                              ["MAD"], _url_google(origen, destino, ida, vuelta)))
        return out


class SerpApiSimulado:
    activo = True

    def __init__(self, hoy):
        self.hoy = hoy

    def restantes(self):
        return 200

    def insights(self, b, origenes, destinos, ida, vuelta):
        return {"nivel": "low", "precio_mas_bajo": None, "rango_tipico": [2150, 2600],
                "historial": None, "url": _url_google(origenes[0], destinos[0], ida, vuelta)}

    def vendedores(self, ins, es_ida_vuelta):
        return [{"vendedor": "LATAM", "precio": 2010.0, "tipo": "Aerolínea", "separado": False},
                {"vendedor": "Iberia", "precio": 2035.0, "tipo": "Aerolínea", "separado": False},
                {"vendedor": "Despegar", "precio": 1995.0, "tipo": "Agencia (OTA)", "separado": False},
                {"vendedor": "Mytrip", "precio": 1940.0, "tipo": "Agencia (OTA)", "separado": False}]
