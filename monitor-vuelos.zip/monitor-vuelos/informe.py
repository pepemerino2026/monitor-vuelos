"""Informe HTML para correo (estilos en línea) y panel con gráfico de evolución."""
from __future__ import annotations

import json
from datetime import datetime
from html import escape

COLORES = {"verde": ("#E6F4EA", "#137333"), "ambar": ("#FEF3E0", "#B06000"), "gris": ("#EEF1F4", "#3C4043")}
NIVEL = {"low": "BAJO", "typical": "TÍPICO", "high": "ALTO"}


def n(x, mon="USD"):
    if x is None:
        return "—"
    return f"{mon} {x:,.0f}".replace(",", ".")


def f(s):
    if not s:
        return ""
    return datetime.strptime(s, "%Y-%m-%d").strftime("%d-%m-%y")


def asunto(resultados, hoy):
    top = sorted(resultados, key=lambda r: ["COMPRAR AHORA", "COMPRAR PRONTO", "ESPERAR"].index(
        r["evaluacion"]["recomendacion"]))[0]
    ev, m = top["evaluacion"], top["mejor"]
    icono = {"COMPRAR AHORA": "🟢", "COMPRAR PRONTO": "🟠", "ESPERAR": "⚪"}[ev["recomendacion"]]
    return (f"{icono} {ev['recomendacion']} · {m.origen}→{m.destino} {n(m.precio)} · "
            f"Vuelos {hoy.strftime('%d-%m')}")


TD = 'style="padding:6px 8px;border-bottom:1px solid #E8EAED;font-size:13px"'
TH = 'style="padding:6px 8px;text-align:left;font-size:11px;color:#5F6368;text-transform:uppercase;border-bottom:2px solid #DADCE0"'


def _tabla(cab, filas):
    h = "".join(f"<th {TH}>{c}</th>" for c in cab)
    b = "".join("<tr>" + "".join(f"<td {TD}>{c}</td>" for c in fila) + "</tr>" for fila in filas)
    return f'<table cellspacing="0" style="border-collapse:collapse;width:100%;margin:6px 0 14px">{"<tr>" + h + "</tr>"}{b}</table>'


def _kpi(titulo, valor, sub=""):
    return (f'<td style="padding:10px 12px;background:#F8F9FA;border-radius:8px;vertical-align:top">'
            f'<div style="font-size:11px;color:#5F6368;text-transform:uppercase">{titulo}</div>'
            f'<div style="font-size:18px;font-weight:700;color:#202124;margin-top:2px">{valor}</div>'
            f'<div style="font-size:12px;color:#5F6368">{sub}</div></td>')


def _h3(t):
    return f'<h3 style="font-size:14px;margin:18px 0 4px;color:#202124">{t}</h3>'


def bloque(r):
    b, ev, m, tim = r["busqueda"], r["evaluacion"], r["mejor"], r["timing"]
    fondo, texto = COLORES[ev["color"]]
    viaje = f"{f(m.ida)} → {f(m.vuelta)}" if m.vuelta else f(m.ida)
    out = [f'<div style="border:1px solid #DADCE0;border-radius:12px;padding:18px;margin:0 0 22px">',
           f'<div style="font-size:17px;font-weight:700;color:#202124">{escape(b["nombre"])}</div>',
           f'<div style="margin:10px 0;padding:10px 14px;background:{fondo};border-radius:8px;color:{texto}">'
           f'<b style="font-size:15px">{ev["recomendacion"]}</b><br><span style="font-size:13px">{ev["motivo"]}</span></div>']

    c = ev["caida_pct"]
    caida = "—" if c is None else (f"−{c:.1f}%" if c > 0 else f"+{abs(c):.1f}%")
    nivel = NIVEL.get(ev["nivel_google"], "—")
    rango = ev["rango_google"]
    rango_s = f"Típico Google: {n(rango[0])}–{n(rango[1])}" if rango else "Sin datos de Google"
    out.append('<table cellspacing="6" style="width:100%;border-collapse:separate"><tr>'
               + _kpi("Mejor precio hoy", n(ev["precio"]), f"{m.origen}→{m.destino} · {viaje}")
               + _kpi("vs. promedio", caida, f"Ref. {n(ev['referencia'])} ({ev['dias_hist']} días)")
               + _kpi("Calificación Google", nivel, rango_s)
               + _kpi("Días a la salida", str(ev["dias_salida"]),
                      "En ventana óptima" if ev["en_ventana"] else "Fuera de ventana óptima")
               + "</tr></table>")
    if ev["alertas"]:
        out.append('<div style="font-size:13px;margin:8px 0">🔔 <b>Alertas:</b> ' + " · ".join(ev["alertas"]) + "</div>")
    if ev["minimo"] is not None:
        out.append(f'<div style="font-size:12px;color:#5F6368">Tu seguimiento: mínimo {n(ev["minimo"])} · '
                   f'típico {n(ev["tipico"])} · máximo {n(ev["maximo"])}</div>')

    # ranking
    out.append(_h3("Mejores opciones de hoy"))
    filas = []
    for o in r["ranking"]:
        ruta = f"{o.origen}→{o.destino}" + (f" (vía {', '.join(o.conexiones)})" if o.conexiones else "")
        filas.append([f"<b>{n(o.precio)}</b>", ruta, f(o.ida) + (f" → {f(o.vuelta)}" if o.vuelta else ""),
                      escape(o.aerolineas), "Directo" if o.escalas == 0 else f"{o.escalas} escala(s)",
                      f'<a href="{escape(o.url)}" style="color:#1A73E8">Ver</a>'])
    out.append(_tabla(["Precio", "Ruta", "Fechas", "Aerolínea", "Escalas", ""], filas))

    # timing
    out.append(_h3("Timing"))
    if tim["semanas"]:
        out.append('<div style="font-size:13px"><b>Semanas más baratas para salir:</b> '
                   + " · ".join(f"semana del {s['semana']} ({n(s['precio'])})" for s in tim["semanas"]) + "</div>")
    if tim["dias"]:
        out.append('<div style="font-size:13px;margin-top:4px"><b>Día de salida:</b> '
                   + " · ".join(f"{d['dia']}{' ★' if d['preferido'] else ''} {d['vs_prom_pct']:+.0f}%"
                                for d in tim["dias"][:4]) + "</div>")
    if tim["curva"]:
        out.append('<div style="font-size:13px;margin-top:4px"><b>Anticipación (precio vs promedio):</b> '
                   + " · ".join(f"{c['tramo']} {c['vs_prom_pct']:+.0f}%" for c in tim["curva"]) + "</div>")
    else:
        out.append(f'<div style="font-size:12px;color:#5F6368;margin-top:4px">Curva de anticipación: acumulando datos '
                   f'({tim["dias_historial"]} días; se calcula desde 3 días por combinación).</div>')

    # canal
    out.append(_h3("Dónde comprar (aerolínea vs agencias)"))
    if r["canal"]:
        filas = [[escape(v["vendedor"]), v["tipo"], n(v["precio"]), n(v["efectivo"]), escape(v["promo"])]
                 for v in r["canal"]["filas"][:6]]
        out.append(_tabla(["Vendedor", "Tipo", "Precio", "Precio efectivo", "Promoción"], filas))
        out.append(f'<div style="font-size:13px"><b>→ {escape(r["canal"]["recomendacion"])}</b></div>')
    else:
        out.append('<div style="font-size:12px;color:#5F6368">Se consulta cuando hay una alerta (ahorra cupo de SerpApi).</div>')

    # alternativas
    if r["separados"] or r["ocultas"]:
        out.append(_h3("Rutas alternativas (tramo de ida)"))
        filas = []
        for s in r["separados"]:
            filas.append(["Boletos separados", s["ruta"], n(s["precio"]), n(s["directo"]),
                          f'<b style="color:{"#137333" if s["ahorro"] > 0 else "#B3261E"}">{n(s["ahorro"])}</b>',
                          escape(s["detalle"])])
        for s in r["ocultas"]:
            filas.append(["Ciudad oculta", s["ruta"], n(s["precio"]), n(s["directo"]),
                          f'<b style="color:#137333">{n(s["ahorro"])}</b>', escape(s["aerolinea"])])
        out.append(_tabla(["Tipo", "Ruta", "Precio", "Directo", "Ahorro", "Detalle"], filas))
        out.append('<div style="font-size:11px;color:#5F6368">Boletos separados: sin protección de conexión, deja '
                   'margen amplio. Ciudad oculta: solo sin maleta documentada y sin vuelta en el mismo boleto; viola '
                   'las condiciones de la aerolínea.</div>')
    out.append("</div>")
    return "".join(out)


def correo(resultados, hoy, serp=None):
    cuerpo = "".join(bloque(r) for r in resultados)
    cupo = ""
    if serp is not None and getattr(serp, "activo", False):
        cupo = f" · Consultas SerpApi restantes este mes: {serp.restantes()}"
    return f"""<!doctype html><html><body style="margin:0;background:#F1F3F4">
<div style="max-width:760px;margin:0 auto;padding:20px;font-family:Arial,Helvetica,sans-serif;color:#202124;background:#fff">
<div style="font-size:12px;color:#5F6368">MONITOR DE VUELOS · {hoy.strftime('%d-%m-%Y')}</div>
<h2 style="margin:4px 0 18px;font-size:22px">Informe de precios</h2>
{cuerpo}
<div style="font-size:11px;color:#5F6368;line-height:1.5;border-top:1px solid #E8EAED;padding-top:10px">
Precios de Google Flights: total del viaje para todos los pasajeros, con impuestos. Confirma siempre el precio final
antes de pagar (algunas agencias suman cargos por medio de pago). Tras comprar, revisa si la aerolínea permite anular
sin costo dentro de 24 horas por si el precio baja. Para terminar la vigilancia, marca <i>comprado: true</i> en la
configuración{cupo}.</div></div></body></html>"""


def panel(resultados, hoy):
    """Página con gráfico de evolución (abrir en el navegador)."""
    datos = [{"nombre": r["busqueda"]["nombre"], "serie": r["serie"],
              "objetivo": r["busqueda"].get("precio_objetivo")} for r in resultados]
    bloques = "".join(f'<section><canvas id="g{i}"></canvas></section>' for i in range(len(datos)))
    return f"""<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Panel de Vuelos</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>body{{font-family:Arial,sans-serif;max-width:900px;margin:0 auto;padding:16px;background:#fff;color:#202124}}
section{{border:1px solid #DADCE0;border-radius:12px;padding:14px;margin:14px 0}}</style></head>
<body><h2>Evolución del mejor precio diario</h2><p style="color:#5F6368">Actualizado {hoy.strftime('%d-%m-%Y')}</p>
{bloques}
<script>
const D={json.dumps(datos)};
D.forEach((d,i)=>{{const x=Object.keys(d.serie);const y=Object.values(d.serie);
const ds=[{{label:'Mejor precio',data:y,borderColor:'#1A73E8',tension:.25,pointRadius:2}}];
if(d.objetivo)ds.push({{label:'Objetivo',data:x.map(()=>d.objetivo),borderColor:'#137333',borderDash:[6,4],pointRadius:0}});
new Chart(document.getElementById('g'+i),{{type:'line',data:{{labels:x,datasets:ds}},
options:{{plugins:{{title:{{display:true,text:d.nombre}}}}}}}});}});
</script></body></html>"""
