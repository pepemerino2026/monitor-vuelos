"""Monitor de vuelos — revisión diaria.

Uso:
  python monitor.py                      # revisión normal (GitHub Actions la corre cada día)
  python monitor.py --modo intensivo     # 2ª revisión del día, solo búsquedas cercanas a la salida
  python monitor.py --simular --dias 21  # prueba sin conexión con 21 días de historial ficticio
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import date, timedelta
from pathlib import Path

import yaml

import analisis
import informe
import notificar
from proveedores import FastFlights, SerpApi, SerpApiSimulado, Simulado

RAIZ = Path(__file__).parent
DATOS = RAIZ / "datos"
HIST = DATOS / "historial.csv"
CAMPOS = ["fecha_consulta", "busqueda_id", "busqueda", "tipo", "origen", "destino", "ida",
          "vuelta", "precio", "aerolineas", "escalas", "conexiones", "url"]


def id_busqueda(b):
    clave = json.dumps({k: str(b.get(k)) for k in (
        "tipo", "origen", "destino", "ida_desde", "ida_hasta", "duracion_min_dias",
        "duracion_max_dias", "adultos", "clase")}, sort_keys=True)
    return hashlib.md5(clave.encode()).hexdigest()[:8]


def leer_historial():
    if not HIST.exists():
        return []
    with HIST.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def guardar_historial(filas):
    nuevo = not HIST.exists()
    with HIST.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CAMPOS)
        if nuevo:
            w.writeheader()
        w.writerows(filas)


def combinaciones(b, hoy):
    """Fechas de ida muestreadas × duraciones (mín, media, máx)."""
    d0 = max(b["ida_desde"], hoy + timedelta(days=1))
    paso = b.get("paso_fechas_dias", 3)
    idas = []
    d = d0
    while d <= b["ida_hasta"]:
        idas.append(d)
        d += timedelta(days=paso)
    if b.get("tipo", "ida_vuelta") == "solo_ida":
        return [(i.isoformat(), None) for i in idas]
    dmin, dmax = b.get("duracion_min_dias", 7), b.get("duracion_max_dias", 14)
    durs = sorted({dmin, (dmin + dmax) // 2, dmax})
    return [(i.isoformat(), (i + timedelta(days=x)).isoformat()) for i in idas for x in durs]


def mejor(lista):
    return min(lista, key=lambda o: o.precio) if lista else None


def procesar(b, fuente, serp, hoy, cfg, historial, modo):
    tope = cfg["general"].get("max_consultas_por_busqueda", 60)
    args = dict(adultos=b.get("adultos", 1), clase=b.get("clase", "economy"),
                escalas_max=b.get("escalas_max"), maletas=b.get("maletas_documentadas", 0))
    combos = combinaciones(b, hoy)
    if len(combos) > tope:             # muestreo uniforme si excede el tope diario
        paso = len(combos) / tope
        combos = [combos[int(i * paso)] for i in range(tope)]

    # 1) grilla principal: aeropuertos principales × fechas
    principal = []
    for o in b["origen"]:
        for de in b["destino"]:
            for ida, vu in combos:
                m = mejor(fuente.buscar(o, de, ida, vu, **args))
                if m:
                    principal.append(m)
    if not principal:
        print("   sin resultados")
        return None
    principal.sort(key=lambda x: x.precio)

    # 2) aeropuertos alternativos en las 3 mejores fechas
    top_fechas = []
    for x in principal:
        if (x.ida, x.vuelta) not in top_fechas:
            top_fechas.append((x.ida, x.vuelta))
        if len(top_fechas) == 3:
            break
    origenes = b["origen"] + (b.get("origen_alternativos") or [])
    destinos = b["destino"] + (b.get("destino_alternativos") or [])
    alternativos = []
    for o in origenes:
        for de in destinos:
            if o in b["origen"] and de in b["destino"]:
                continue
            for ida, vu in top_fechas:
                m = mejor(fuente.buscar(o, de, ida, vu, **args))
                if m:
                    alternativos.append(m)

    m0 = principal[0]

    # 3) boletos separados vía hub (tramo de ida) vs directo solo ida
    separados = []
    bs = b.get("boletos_separados") or {}
    ida_dir = None
    if bs.get("activo") or (b.get("ciudad_oculta") or {}).get("activo"):
        ida_dir = mejor(fuente.buscar(m0.origen, m0.destino, m0.ida, None, **args))
    if bs.get("activo") and ida_dir:
        for hub in bs.get("hubs", []):
            t1 = mejor(fuente.buscar(m0.origen, hub, m0.ida, None, **args))
            t2 = mejor(fuente.buscar(hub, m0.destino, m0.ida, None, **args))
            if t1 and t2:
                total = t1.precio + t2.precio
                separados.append({"ruta": f"{m0.origen}→{hub}→{m0.destino}", "fecha": m0.ida,
                                  "precio": total, "directo": ida_dir.precio,
                                  "ahorro": ida_dir.precio - total,
                                  "detalle": f"{t1.aerolineas} {t1.precio:,.0f} + {t2.aerolineas} {t2.precio:,.0f}",
                                  "url": t2.url})
        separados.sort(key=lambda x: -x["ahorro"])

    # 4) ciudad oculta (informativo)
    ocultas = []
    co = b.get("ciudad_oculta") or {}
    if co.get("activo") and ida_dir:
        for mas_alla in co.get("destinos_mas_alla", []):
            for x in fuente.buscar(m0.origen, mas_alla, m0.ida, None, **{**args, "maletas": 0}):
                if m0.destino in x.conexiones and x.precio < ida_dir.precio:
                    ocultas.append({"ruta": f"{m0.origen}→{m0.destino} (boleto a {mas_alla})",
                                    "fecha": m0.ida, "precio": x.precio, "directo": ida_dir.precio,
                                    "ahorro": ida_dir.precio - x.precio, "aerolinea": x.aerolineas,
                                    "url": x.url})
        ocultas.sort(key=lambda x: -x["ahorro"])

    # historial
    bid = id_busqueda(b)
    filas = []
    for tipo, lst in (("principal", principal), ("alternativo", alternativos)):
        for x in lst:
            filas.append({"fecha_consulta": hoy.isoformat(), "busqueda_id": bid,
                          "busqueda": b["nombre"], "tipo": tipo, "origen": x.origen,
                          "destino": x.destino, "ida": x.ida, "vuelta": x.vuelta or "",
                          "precio": x.precio, "aerolineas": x.aerolineas, "escalas": x.escalas,
                          "conexiones": "-".join(x.conexiones), "url": x.url})
    historial_total = historial + filas

    # ranking del día
    todas = sorted(principal + alternativos, key=lambda x: x.precio)
    mejor_hoy = todas[0]
    serie = analisis.serie_diaria(historial_total, bid)

    # SerpApi: calificación de precio y vendedores
    insights = None
    if serp and serp.activo and serp.restantes() > 0:
        insights = serp.insights(b, [mejor_hoy.origen], [mejor_hoy.destino], mejor_hoy.ida, mejor_hoy.vuelta)
    ev = analisis.evaluar(hoy, b, mejor_hoy, serie, insights, cfg["timing"])
    vend = []
    modo_v = cfg.get("serpapi", {}).get("consultar_vendedores", "en_alerta")
    if insights and serp.restantes() >= 3 and (modo_v == "siempre" or (modo_v == "en_alerta" and ev["alertas"])):
        vend = serp.vendedores(insights, bool(mejor_hoy.vuelta))
    tim = analisis.timing(hoy, principal, historial_total, bid, cfg["timing"])
    can = analisis.canal(vend, cfg["canal_compra"])

    return {"busqueda": b, "id": bid, "mejor": mejor_hoy, "ranking": todas[:8], "evaluacion": ev,
            "timing": tim, "canal": can, "separados": separados[:3], "ocultas": ocultas[:3],
            "serie": serie, "insights": insights, "filas": filas,
            "consultas": len(combos) * len(b["origen"]) * len(b["destino"])}


def vigente(b, hoy):
    if not b.get("activa", True) or b.get("comprado"):
        return False, "comprado o inactiva"
    lim = b.get("fecha_limite_compra")
    if isinstance(lim, date) and hoy > lim:
        return False, "pasó la fecha límite de compra"
    if hoy >= b["ida_hasta"]:
        return False, "pasó la ventana de viaje"
    return True, ""


def ejecutar(cfg, hoy, simular, modo, enviar=True, guardar_informe=True):
    DATOS.mkdir(exist_ok=True)
    fuente = Simulado(hoy) if simular else FastFlights(cfg["general"])
    serp = SerpApiSimulado(hoy) if simular else SerpApi(cfg.get("serpapi", {}), cfg["general"], DATOS)
    historial = leer_historial()
    resultados = []
    for b in cfg["busquedas"]:
        ok, motivo = vigente(b, hoy)
        if not ok:
            print(f"- {b['nombre']}: vigilancia terminada ({motivo})")
            continue
        if modo == "intensivo":
            dias = (b["ida_desde"] - hoy).days
            if dias > cfg["timing"].get("frecuencia_intensiva_dias_antes", 60):
                continue
        print(f"- {b['nombre']}")
        r = procesar(b, fuente, serp, hoy, cfg, historial, modo)
        if r:
            guardar_historial(r["filas"])
            historial += r["filas"]
            resultados.append(r)

    if not resultados:
        return None
    hay_alertas = any(r["evaluacion"]["alertas"] for r in resultados)
    frec = cfg["notificacion"].get("frecuencia", "diaria")
    dia_sem = analisis.DIAS[hoy.weekday()]
    toca = (modo != "intensivo" and (frec == "diaria" or
            (frec == "semanal" and cfg["notificacion"].get("dia_semanal", "lunes")[:3] == dia_sem))) or hay_alertas

    html = informe.correo(resultados, hoy, serp)
    if guardar_informe:
        (RAIZ / "informes").mkdir(exist_ok=True)
        (RAIZ / "informes" / "ultimo_informe.html").write_text(html, encoding="utf-8")
        (RAIZ / "informes" / "panel.html").write_text(informe.panel(resultados, hoy), encoding="utf-8")
    if enviar and toca:
        asunto = informe.asunto(resultados, hoy)
        notificar.enviar(cfg["notificacion"]["email_destino"], asunto, html)
    elif enviar:
        print("Sin correo hoy (frecuencia configurada y sin alertas).")
    return resultados


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(RAIZ / "config.yaml"))
    ap.add_argument("--modo", default="normal", choices=["normal", "intensivo"])
    ap.add_argument("--simular", action="store_true", help="datos ficticios, sin conexión")
    ap.add_argument("--dias", type=int, default=0, help="(con --simular) días de historial a generar")
    ap.add_argument("--fecha", help="fecha de 'hoy' (pruebas), AAAA-MM-DD")
    ap.add_argument("--sin-correo", action="store_true")
    a = ap.parse_args()

    cfg = yaml.safe_load(Path(a.config).read_text(encoding="utf-8"))
    hoy = date.fromisoformat(a.fecha) if a.fecha else date.today()
    if a.simular and a.dias:
        for k in range(a.dias, 0, -1):
            ejecutar(cfg, hoy - timedelta(days=k), True, "normal", enviar=False, guardar_informe=False)
    ejecutar(cfg, hoy, a.simular, a.modo, enviar=not a.sin_correo)


if __name__ == "__main__":
    main()
