# Monitor de Vuelos

Revisa todos los días los precios de los viajes que definas en `config.yaml` y te envía un informe por correo con:

- **Mejores opciones del día**: fechas flexibles, aeropuertos alternativos y ranking.
- **Recomendación**: COMPRAR AHORA, COMPRAR PRONTO o ESPERAR, con el motivo.
- **Timing**: semanas y días más baratos para volar, curva de anticipación y calificación de Google (bajo, típico o alto).
- **Dónde comprar**: aerolínea vs. agencias (OTAs), con tus promociones bancarias aplicadas.
- **Rutas alternativas**: boletos separados vía hubs y ciudad oculta (opcional).
- **Alertas**: caída de precio, precio bajo tu objetivo, alza sostenida y cierre de la ventana de compra.

Costo: **$0**. Corre en GitHub Actions (gratis), lee Google Flights con la librería `fast-flights` y usa el plan gratuito de SerpApi (250 consultas al mes).

---

## Instalación (unos 20 minutos, una sola vez)

### 1. Crear el repositorio en GitHub
1. Crea una cuenta en https://github.com si no tienes.
2. **New repository** → nombre: `monitor-vuelos` → marca **Private** → Create.
3. **Add file → Upload files** → arrastra **todo el contenido** de la carpeta descomprimida, incluida la carpeta `.github`. En Windows, si no la ves, activa "Elementos ocultos" en el Explorador. Luego **Commit changes**.

### 2. Clave gratuita de SerpApi
1. Regístrate en https://serpapi.com (plan Free).
2. Copia tu **API Key** desde el panel ("Your Account").

### 3. Contraseña de aplicación de Gmail
1. En https://myaccount.google.com activa la **verificación en 2 pasos**.
2. Ve a https://myaccount.google.com/apppasswords → crea una con el nombre "Monitor vuelos" → copia las 16 letras.

### 4. Cargar las claves en GitHub
En el repositorio: **Settings → Secrets and variables → Actions → New repository secret**. Crea estos tres secretos:

| Nombre | Valor |
|---|---|
| `SERPAPI_KEY` | tu clave de SerpApi |
| `GMAIL_USER` | tu cuenta de Gmail que envía el correo |
| `GMAIL_APP_PASSWORD` | las 16 letras del paso 3 |

### 5. Probar
**Actions → Revisión diaria de vuelos → Run workflow**. En unos 5 minutos llega el primer informe. Desde ese momento corre solo todos los días a las 08:17, y de nuevo a las 20:17 para los viajes que salen en menos de 60 días.

---

## Uso diario

- **Agregar o cambiar un viaje**: edita `config.yaml` directamente en GitHub (ícono del lápiz). Cada bloque bajo `busquedas:` es un viaje.
- **Al comprar**: cambia a `comprado: true` para terminar la vigilancia de ese viaje.
- **Gráfico de evolución**: descarga `informes/panel.html` del repositorio y ábrelo en el navegador.
- **Historial completo**: `datos/historial.csv` (se abre en Excel).

## Cómo decide

| Recomendación | Cuándo |
|---|---|
| **COMPRAR AHORA** | Precio bajo tu objetivo, mínimo histórico, caída mayor al umbral o Google lo califica como bajo |
| **COMPRAR PRONTO** | Faltan menos de 45 días, el precio sube 3 días seguidos o se acerca tu fecha límite |
| **ESPERAR** | Precio típico y todavía hay ventana de compra |

Todos los parámetros (umbrales, ventana de 60–180 días, días preferidos, etc.) se ajustan en `config.yaml`.

## Consumo de SerpApi (plan gratuito)
- 1 consulta diaria por viaje, para la calificación de precio. Con 2 revisiones al día en modo intensivo, son 2.
- 3 consultas para comparar vendedores, solo cuando hay una alerta.
- Con 2 o 3 viajes activos te mantienes dentro de las 250 consultas al mes. El informe muestra el cupo restante.

## Limitaciones
- `fast-flights` no es una API oficial: lee Google Flights como un navegador. Si Google cambia su página o bloquea las consultas, la grilla puede venir vacía. En ese caso, actualiza la versión en `requirements.txt` o avísame para ajustarlo.
- Los cargos por medio de pago de las agencias no siempre aparecen en Google: confirma el precio final antes de pagar.
- Boletos separados y ciudad oculta son informativos y tienen riesgos (ver las notas del informe).

## Prueba local sin conexión
```
pip install -r requirements.txt
python monitor.py --simular --dias 21 --sin-correo
```
Genera `informes/ultimo_informe.html` con datos ficticios.
