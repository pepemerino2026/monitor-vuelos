"""Análisis: referencia de precio, alertas, timing, canal de compra y recomendación."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime
from statistics import mean, median

DIAS = ["lun", "mar", "mie", "jue", "vie", "sab", "dom"]
DIAS_LARGO = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]


def _d(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


def serie_diaria(historial, id_busqueda):
    """Precio mínimo del día (rutas principales y alternativas) → {fecha: precio}."""
    s = {}
    for r in historial:
        if r["busqueda_id"] != id_busqueda or r["tipo"] not in ("principal", "alternativo"):
            continue
        p = float(r["precio"])
        f = r["fecha_consulta"]
        s[f] = min(p, s.get(f, p))
    return dict(sorted(s.items()))


def timing(hoy, ofertas_hoy, historial, id_busqueda, cfg_t):
    """Semanas y días más baratos (grilla de hoy) + curva de anticipación (historial)."""
    # semanas más baratas para volar (por fecha de ida)
    por_semana = defaultdict(list)
    por_dia = defaultdict(list)
    for o in ofertas_hoy:
        d = _d(o.ida)
        lunes = date.fromordinal(d.toordinal() - d.weekday())
        por_semana[lunes].append(o.precio)
        por_dia[d.weekday()].append(o.precio)
    semanas = sorted(((min(v), k) for k, v in por_semana.items()))[:3]
    semanas = [{"semana": k.strftime("%d-%m"), "precio": p} for p, k in semanas]

    dias = []
    if por_dia:
        prom_total = mean(min(v) for v in por_dia.values())
        pref = cfg_t.get("dias_vuelo_preferidos", [])
        for wd in sorted(por_dia, key=lambda w: min(por_dia[w])):
            m = min(por_dia[wd])
            dias.append({"dia": DIAS_LARGO[wd], "precio": m,
                         "vs_prom_pct": round((m / prom_total - 1) * 100, 1),
                         "preferido": DIAS[wd] in pref})

    # curva de anticipación: precio de cada combinación vs su propio promedio
    combos = defaultdict(list)
    for r in historial:
        if r["busqueda_id"] == id_busqueda and r["tipo"] == "principal":
            combos[(r["origen"], r["destino"], r["ida"], r["vuelta"])].append(
                (r["fecha_consulta"], float(r["precio"])))
    tramos = [(0, 30, "< 30 días"), (30, 60, "30–60 días"), (60, 120, "60–120 días"),
              (120, 180, "120–180 días"), (180, 9999, "> 180 días")]
    acum = defaultdict(list)
    dias_hist = len({f for v in combos.values() for f, _ in v})
    for (o, de, ida, vu), puntos in combos.items():
        if len(puntos) < 3:
            continue
        prom = mean(p for _, p in puntos)
        for f, p in puntos:
            ant = (_d(ida) - _d(f)).days
            for a, b, et in tramos:
                if a <= ant < b:
                    acum[et].append(p / prom)
    curva = [{"tramo": et, "vs_prom_pct": round((mean(acum[et]) - 1) * 100, 1), "n": len(acum[et])}
             for _, _, et in tramos if acum.get(et)]
    return {"semanas": semanas, "dias": dias, "curva": curva, "dias_historial": dias_hist}


def canal(vendedores, cfg_c):
    """Compara aerolínea vs OTAs con promociones bancarias y diferencia mínima."""
    if not vendedores:
        return None
    excl = {v.lower() for v in cfg_c.get("vendedores_excluidos", [])}
    promos = cfg_c.get("promociones_bancarias") or []
    filas = []
    for v in vendedores:
        if v["vendedor"].lower() in excl:
            continue
        efectivo = v["precio"]
        promo = ""
        for p in promos:
            if p.get("vendedor", "").lower() in v["vendedor"].lower():
                efectivo = round(v["precio"] * (1 - p.get("descuento_pct", 0) / 100))
                promo = f"-{p.get('descuento_pct')}% {p.get('tarjeta', '')}".strip()
        filas.append({**v, "efectivo": efectivo, "promo": promo})
    if not filas:
        return None
    filas.sort(key=lambda x: x["efectivo"])
    aer = [f for f in filas if f["tipo"] == "Aerolínea"]
    ota = [f for f in filas if f["tipo"] != "Aerolínea"]
    mejor_aer = aer[0] if aer else None
    mejor_ota = ota[0] if ota else None
    umbral = cfg_c.get("diferencia_minima_ota_usd", 30)
    if mejor_aer and mejor_ota and mejor_aer["efectivo"] - mejor_ota["efectivo"] >= umbral:
        rec = (f"Comprar en {mejor_ota['vendedor']}: ahorra "
               f"{mejor_aer['efectivo'] - mejor_ota['efectivo']:,.0f} vs aerolínea "
               f"(verifica cargos por medio de pago antes de pagar).")
    elif mejor_aer:
        dif = (mejor_aer["efectivo"] - mejor_ota["efectivo"]) if mejor_ota else 0
        rec = (f"Comprar directo en {mejor_aer['vendedor']}"
               + (f": la OTA más barata ahorra solo {dif:,.0f}, bajo el mínimo de {umbral}." if dif > 0 else "."))
    else:
        rec = f"Solo hay agencias: la más barata es {mejor_ota['vendedor']}."
    return {"filas": filas, "recomendacion": rec}


def evaluar(hoy, busqueda, mejor, serie, insights, cfg_t):
    """Alertas y recomendación COMPRAR AHORA / COMPRAR PRONTO / ESPERAR."""
    precio = mejor.precio
    hoy_s = hoy.isoformat()
    previos = [p for f, p in serie.items() if f < hoy_s]
    n = cfg_t.get("promedio_movil_dias", 14)
    ref = mean(previos[-n:]) if previos else None
    caida = round((1 - precio / ref) * 100, 1) if ref else None
    minimo = min(previos) if previos else None
    tipico = median(previos) if previos else None
    maximo = max(previos) if previos else None

    k = cfg_t.get("dias_alza_sostenida", 3)
    ult = list(serie.values())[-(k + 1):]
    alza = len(ult) == k + 1 and all(b > a for a, b in zip(ult, ult[1:]))

    dias_salida = (_d(mejor.ida) - hoy).days
    v_min, v_max = cfg_t.get("ventana_optima_dias", [60, 180])
    en_ventana = v_min <= dias_salida <= v_max
    limite = busqueda.get("fecha_limite_compra")
    dias_limite = (limite - hoy).days if isinstance(limite, date) else None
    nivel = (insights or {}).get("nivel")
    objetivo = busqueda.get("precio_objetivo")

    alertas = []
    if objetivo and precio <= objetivo:
        alertas.append(f"Bajo tu precio objetivo (USD {objetivo:,.0f})".replace(",", "."))
    if caida is not None and caida >= cfg_t.get("umbral_caida_pct", 10):
        alertas.append(f"Caída de {caida}% vs promedio de {min(len(previos), n)} días")
    if minimo is not None and len(previos) >= 7 and precio < minimo:
        alertas.append("Mínimo histórico de tu seguimiento")
    if alza:
        alertas.append(f"Precio subiendo {k} días seguidos")
    if dias_salida <= cfg_t.get("dias_alerta_cierre", 45):
        alertas.append(f"Faltan {dias_salida} días para la salida")
    if dias_limite is not None and dias_limite <= 7:
        alertas.append(f"Faltan {dias_limite} días para tu fecha límite de compra")

    oportunidad = (
        (objetivo and precio <= objetivo)
        or (minimo is not None and len(previos) >= 7 and precio < minimo)
        or (caida is not None and caida >= cfg_t.get("umbral_caida_pct", 10))
        or (nivel == "low" and (caida or 0) >= 0)
    )
    if oportunidad:
        rec, color = "COMPRAR AHORA", "verde"
        motivo = "El precio está en zona de oportunidad (objetivo, mínimo o caída relevante)."
    elif alza or dias_salida <= cfg_t.get("dias_alerta_cierre", 45) or (dias_limite is not None and dias_limite <= 7):
        rec, color = "COMPRAR PRONTO", "ambar"
        motivo = "Se cierra la ventana de compra o el precio viene subiendo; esperar tiene más riesgo que beneficio."
    else:
        rec, color = "ESPERAR", "gris"
        motivo = ("Estás dentro de la ventana óptima y el precio es típico; seguimos vigilando."
                  if en_ventana else
                  "Aún falta para la ventana óptima de compra; seguimos acumulando historial.")

    return {
        "precio": precio, "referencia": ref, "caida_pct": caida, "minimo": minimo,
        "tipico": tipico, "maximo": maximo, "alza": alza, "dias_salida": dias_salida,
        "en_ventana": en_ventana, "dias_limite": dias_limite, "nivel_google": nivel,
        "rango_google": (insights or {}).get("rango_tipico"), "alertas": alertas,
        "oportunidad": bool(oportunidad) or alza or rec == "COMPRAR PRONTO",
        "recomendacion": rec, "color": color, "motivo": motivo, "dias_hist": len(previos),
    }
