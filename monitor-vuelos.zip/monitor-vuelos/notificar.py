"""Envío del informe por Gmail (SMTP con contraseña de aplicación)."""
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


def enviar(destino, asunto, html):
    usuario = os.environ.get("GMAIL_USER")
    clave = os.environ.get("GMAIL_APP_PASSWORD")
    if not usuario or not clave:
        print("Correo no enviado: faltan GMAIL_USER / GMAIL_APP_PASSWORD. Informe guardado en informes/.")
        return False
    msg = MIMEMultipart("alternative")
    msg["Subject"] = asunto
    msg["From"] = f"Monitor de Vuelos <{usuario}>"
    msg["To"] = destino
    msg.attach(MIMEText("Abre este correo en formato HTML para ver el informe.", "plain", "utf-8"))
    msg.attach(MIMEText(html, "html", "utf-8"))
    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as s:
        s.login(usuario, clave)
        s.sendmail(usuario, [destino], msg.as_string())
    print(f"Correo enviado a {destino}")
    return True
